    
    <?php $__env->startSection('content'); ?>

    <div class="app-container">

        <!-- App hero header starts -->
        <div class="app-hero-header d-flex align-items-center">

            <!-- Breadcrumb starts -->
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <i class="ri-home-8-line lh-1 pe-3 me-3 border-end"></i>
                    <a href="/">Home</a>
                </li>
                <li class="breadcrumb-item text-primary" aria-current="page">
                    Inquiry List
                </li>
            </ol>
            <!-- Breadcrumb ends -->
        </div>
        <!-- App Hero header ends -->

        <!-- App body starts -->
        <div class="app-body">
            <div class="col-sm-12">
                <div class="card mb-3">
                    <div class="card-header">
                        <h5 class="card-title">Inquiry List</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-outer">
                            <div class="table-responsive">
                                <table class="table align-middle table-hover m-0 truncate">
                                    <thead>
                                        <tr>
                                            <th scope="col">Name</th>
                                            <th scope="col">Email</th>
                                            <th scope="col">Date</th>
                                            <th scope="col">Subject</th>
                                            <th scope="col">Message</th>
                                            <th scope="col">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $inquiries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="<?php echo e($inq->is_read ? '' : 'unread-inquiry'); ?>">

                                            <td><?php echo e(ucfirst($inq->name)); ?></td>
                                            <td><?php echo e($inq->email); ?></td>
                                            <td><?php echo e($inq->created_at->format('M d, Y h:i:s A')); ?></td>
                                            <td><?php echo e($inq->subject); ?></td>
                                            <td style="text-wrap: wrap;"><?php echo e($inq->message); ?></td>
                                            <td>
                                                <div class="d-flex align-items-center gap-2">

                                                    <a class="btn btn-info btn-sm" href="<?php echo e(route('reply_inq', $inq->id)); ?>" onclick="return confirm(' Do you want to reply this inquiry?')">
                                                        <i class="ri-reply-fill"></i>
                                                        <span>Reply</span>
                                                    </a>

                                                    <a class="btn btn- btn-sm" href="<?php echo e(route('view_inq', $inq->id)); ?>">
                                                        <i class="ri-eye-2-line"></i>
                                                        <span>View</span>
                                                    </a>

                                                    <a class="btn btn-danger btn-sm" href="<?php echo e(route('delete_inq', $inq->id)); ?>" onclick="return confirm('Delete message?')">
                                                        <i class="ri-delete-bin-line"></i>
                                                        <span>Delete</span>
                                                    </a>


                                                </div>

                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <!-- App body ends -->
        <style>
            .unread-inquiry {
                background-color: red !important;
            }
        </style>

        <!-- App footer starts -->
        <div class="app-footer bg-white">
            <span>© Zeltek Super Admin 2024</span>
        </div>
        <!-- App footer ends -->

    </div>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MY LAPTOP\Documents\laravel\zeltek\resources\views/admin/inquiry.blade.php ENDPATH**/ ?>