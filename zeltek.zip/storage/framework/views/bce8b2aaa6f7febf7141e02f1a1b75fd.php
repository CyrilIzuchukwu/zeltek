    
    <?php $__env->startSection('content'); ?>

    <div class="app-container">

        <!-- App hero header starts -->
        <div class="app-hero-header d-flex align-items-center">

            <!-- Breadcrumb starts -->
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <i class="ri-home-8-line lh-1 pe-3 me-3 border-end"></i>
                    <a href="/">Home</a>
                </li>
                <li class="breadcrumb-item text-primary" aria-current="page">
                    Testimonial List
                </li>
            </ol>
            <!-- Breadcrumb ends -->
        </div>
        <!-- App Hero header ends -->

        <!-- App body starts -->
        <div class="app-body">


            <div class="col-sm-12 mt-5">
                <div class="card mb-3">
                    <div class="card-header d-flex align-items-center justify-content-between">
                        <h5 class="card-title">Testimonial List</h5>
                        <div>
                            <a href="<?php echo e(route('add_testimonial')); ?>" class="btn btn-danger">Add Testimonial</a>
                        </div>
                    </div>
                    <?php if($testimonials->count() > 0): ?>

                    <div class="card-body">
                        <div class="table-outer">
                            <div class="table-responsive">
                                <table class="table align-middle table-hover m-0 truncate">
                                    <thead>
                                        <tr>
                                            <th scope="col">Service Type</th>
                                            <th scope="col">Client Name</th>
                                            <th scope="col">Logo</th>
                                            <th scope="col">Testimonial</th>
                                            <th scope="col">Date</th>
                                            <th scope="col">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>

                                            <td><?php echo e($testimonial->service_type); ?></td>
                                            <td><?php echo e($testimonial->client_name); ?></td>


                                            <td>
                                                <div class="logo">
                                                    <img src="<?php echo e(asset('client_logos/' . $testimonial->client_logo)); ?>" width="100" height="60" alt="client logo">
                                                </div>
                                            </td>
                                            <td style="text-wrap: wrap;"><?php echo e($testimonial->testimonial); ?></td>
                                            <td><?php echo e($testimonial->created_at->format('M d, Y')); ?></td>
                                            <td>
                                                <div class="d-flex align-items-center">

                                                    <a class="btn btn-success btn-sm me-2" href="<?php echo e(route('edit_testimonial', $testimonial->id)); ?>" onclick="return confirm('Are you sure you want to edit?')">
                                                        <i class="ri-edit-fill"></i>
                                                        <span>Edit</span>
                                                    </a>

                                                    <a class="btn btn-danger btn-sm" href="<?php echo e(route('delete_testimonial', $testimonial->id)); ?>" onclick="return confirm('Are you sure you want to delete?')">
                                                        <i class="ri-delete-bin-line"></i>
                                                        <span>Delete</span>
                                                    </a>
                                                </div>

                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        
                        <div class="d-flex justify-content-between mt-4">
                            <div>
                                Showing <?php echo e($testimonials->firstItem()); ?> to <?php echo e($testimonials->lastItem()); ?> of <?php echo e($testimonials->total()); ?> results
                            </div>
                            <div>
                                <?php echo e($testimonials->links('pagination::bootstrap-4')); ?>

                            </div>
                        </div>
                    </div>

                    <?php else: ?>
                    <div class="table-responsive">
                        <table class="table align-middle table-hover m-0 truncate">
                            <thead>
                                <tr class="text-center ">
                                    <th scope="col" class="text-danger mb-4" colspan="6">No Record Found</th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                    <?php endif; ?>

                </div>
            </div>

        </div>
        <!-- App body ends -->

        <!-- App footer starts -->
        <div class="app-footer bg-white">
            <span>© Zeltek Super Admin 2024</span>
        </div>
        <!-- App footer ends -->

    </div>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MY LAPTOP\Documents\laravel\zeltek\resources\views/testimonial/testimonials.blade.php ENDPATH**/ ?>