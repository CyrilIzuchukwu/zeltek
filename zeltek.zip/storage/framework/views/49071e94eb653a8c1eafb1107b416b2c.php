    
    <?php $__env->startSection('content'); ?>

    <div class="sc-breadcrumb-style sc-pt-70 sc-pb-70">
        <div class="container position-relative">
            <div class="row">
                <div class="col-lg-12">
                    <div class="sc-slider-content p-z-idex">
                        <div class="sc-slider-subtitle">Home - Contact Us</div>
                        <h1 class="slider-title white-color sc-mb-25 sc-sm-mb-15">Contact Us</h1>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="sc-contact-section sc-pt-100 sc-md-pt-70 sc-pb-80 sc-md-pb-50">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="sc-md-pr-10">
                        <div class="sc-heading-area sc-pr-30 sc-pt-5">
                            <span class="sub-title"><i class="icon-line me-2"></i>24/7 Customer Support</span>
                            <h2 class="title">Need Assistance? <span class="primary-color">Contact Us</span></h2>
                        </div>
                        <div class="sc-contact-info sc-mt-35 sc-mb-20">
                            <ul class="list-gap white-color">
                                <li><i class="icon-phone-2"></i><a href="tel:+1(520)2563650"> <?php echo e($contact->phone ?? ''); ?></a></li>

                                <li><i class="icon-mail"></i><a href="mailto:zeltekgroup@gmail.com"><?php echo e($contact->email ?? ''); ?></a></li>

                                <li>
                                    <i class="icon-gap_2"></i>
                                    <p><?php echo e($contact->location ?? ''); ?></p>
                                </li>
                            </ul>
                        </div>
                    </div>


                </div>
                <div class="col-lg-6">
                    <div class="contact-box sc-md-mb-10 sc-md-mt-45">
                        <h4 class="contact-title sc-pb-15">Contact Form</h4>
                        <form id="contactForm" method="POST">

                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-box">
                                        <label for="">Name <span class="text-danger">*</span></label>
                                        <input class="from-control" value="<?php echo e(old('name')); ?>" type="text" id="name" name="name" placeholder="Full name" required="">
                                        <span class="text-danger"><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <label for="">Email <span class="text-danger">*</span></label>
                                    <input class="from-control" value="<?php echo e(old('email')); ?>" type="email" id="address" name="email" placeholder="Your email" required="">
                                    <span class="text-danger"><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-box">
                                        <label for="">Phone No <span class="text-danger">*</span></label>
                                        <input class="from-control" value="<?php echo e(old('phone')); ?>" type="text" id="phone" name="phone" placeholder="Your phone">
                                        <span class="text-danger"><?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <label for="">Subject <span class="text-danger">*</span></label>
                                    <input class="from-control" value="<?php echo e(old('subject')); ?>" type="text" id="subject" name="subject" placeholder="Subject">
                                    <span class="text-danger"><?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                                </div>

                                <div class="form-box">
                                    <label for="">Message <span class="text-danger">*</span></label>
                                    <textarea id="message" name="message" placeholder="Your Request"><?php echo e(old('message')); ?></textarea>
                                    <span class="text-danger"><?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                                </div>
                            </div>
                            <div class="submit-button sc-primary-btn">
                                <input type="submit" value="Send Message">
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>



    <!-- map  -->
    <div class="sc-google-map sc-pb-80">
        <div class="sc-gray-icon"><i class="icon-gap_2"></i></div>
        <iframe height="550" src="https://maps.google.com/maps?width=100%25&amp;height=550&amp;hl=en&amp;q=Prime%20Waters%20Garden%20Estate,%20Lekki%20Phase%201,%20Lagos%20Nigeria+(Zeltek)&amp;t=&amp;z=14&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"></iframe>
    </div>

    <!-- <div style="width: 100%"><iframe width="100%" height="650" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?width=100%25&amp;height=650&amp;hl=en&amp;q=Prime%20Waters%20Garden%20Estate,%20Lekki%20Phase%201,%20Lagos%20Nigeria+(Zeltek)&amp;t=&amp;z=14&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"><a href="https://www.gps.ie/">gps trackers</a></iframe></div> -->


    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <?php if(session('message')): ?>
    <script>
        swal("Successful!", "<?php echo e(session('message')); ?>!", "success");
    </script>
    <?php endif; ?>
    <?php if(session('error')): ?>
    <script>
        swal("Error!", "<?php echo e(session('error')); ?>!", "warning");
    </script>
    <?php endif; ?>
    <?php if(Session::has('success')): ?>
    <script>
        swal("Successful!", "<?php echo e(Session::get('success')); ?>!", "success");
    </script>
    <?php endif; ?>

    <?php if(Session::has('error')): ?>
    <script>
        swal("Error!", "<?php echo e(Session::get('error')); ?>!", "warning");
    </script>
    <?php endif; ?>


    <script src="<?php echo e(asset('admin_assets/assets/js/jquery.min.js')); ?>"></script>
    <script>
        $(document).ready(function() {
            $('#contactForm').on('submit', function(e) {
                e.preventDefault(); // Prevent default form submission

                var formData = $(this).serialize(); // Serialize form data
                var form = this; // Store reference to the form

                $.ajax({
                    type: 'POST',
                    url: '<?php echo e(route("make_contact")); ?>', // URL to submit the form data
                    data: formData,
                    success: function(response) {
                        if (response.success) {
                            // Display SweetAlert success message
                            swal("Successful!", response.success, "success")
                                .then((value) => {
                                    // Clear the form fields after closing the SweetAlert box
                                    $(form).find('input[type=text], input[type=email], textarea').val('');
                                });
                        }
                    },
                    error: function(xhr) {
                        // Handle errors
                        if (xhr.responseJSON && xhr.responseJSON.errors) {
                            let errors = xhr.responseJSON.errors;
                            let message = "Something went wrong.";
                            if (errors) {
                                message = Object.values(errors).map((e) => e.join('\n')).join('\n');
                            }
                            swal("Error!", message, "error");
                        } else {
                            swal("Error!", "Failed to submit. Please try again.", "error");
                        }
                    }
                });
            });
        });
    </script>


    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MY LAPTOP\Documents\laravel\zeltek\resources\views/contact_us.blade.php ENDPATH**/ ?>