    @extends('layout.app')
    @section('content')

    <div class="sc-breadcrumb-style sc-pt-80 sc-pb-80">
        <div class="container position-relative">
            <div class="row">
                <div class="col-lg-12">
                    <div class="sc-slider-content p-z-idex">
                        <div class="sc-slider-subtitle">Home - Privacy Policy</div>
                        <h1 class="slider-title white-color sc-mb-25 sc-sm-mb-15">Privacy Policy</h1>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="privacy-policy-area sc-pt-60 sc-pb-60">
        <div class="container">
            <div class="single-content">
                <div class="privacy-text">
                    <h3 class="heading">1. Introduction</h3>
                    <p>
                        Zeltek Limited ("we", "our", "us") is committed to protecting the privacy of our clients, website
                        visitors, and users of our services. This Privacy Policy outlines how we collect, use, disclose, and
                        protect your personal information.
                    </p>
                </div>


                <div class="privacy-text">
                    <h3 class="heading">2. Information We Collect</h3>
                    <p>We may collect the following types of information:</p>
                    <ul>
                        <li><b>Personal Information:</b> Name, email address, phone number, job title, and company name.</li>
                        <li> <b>Payment Information:</b> Credit card details and billing information.</li>
                        <li><b>Technical Information:</b> IP address, browser type, operating system, and usage data.</li>
                        <li><b>Other Information:</b> Any other information you provide to us voluntarily, such as through surveys
                            or contact forms.</li>

                    </ul>
                </div>

                <div class="privacy-text">
                    <h3 class="heading">3. How We Use Your Information</h3>
                    <p>We use the information we collect for the following purposes:</p>
                    <ul>
                        <li><b>Service Delivery:</b> To provide and manage our project management and training services.</li>
                        <li> <b>Communication:</b> To communicate with you about our services, updates, and promotional offers.</li>
                        <li><b>Billing and Payments:</b> To process payments and manage billing.</li>
                        <li><b>Improvement:</b> To improve our services, website, and user experience.</li>
                        <li><b>Compliance:</b> To comply with legal obligations and protect our rights.</li>

                    </ul>
                </div>

                <div class="privacy-text">
                    <h3 class="heading">4. Sharing Your Information</h3>
                    <p>We do not sell or rent your personal information to third parties. We may share your information
                        with:</p>
                    <ul>
                        <li><b>Service Providers:</b> Third-party vendors who assist us in providing our services, such as payment
                            processors and IT support.</li>
                        <li> <b>Legal Obligations:</b> Authorities if required by law or to protect our rights and comply with legal
                            processes.</li>
                        <li><b>Business Transfers:</b> In the event of a merger, acquisition, or sale of all or a portion of our assets.</li>

                    </ul>
                </div>
            </div>
        </div>
    </div>

    @endsection
