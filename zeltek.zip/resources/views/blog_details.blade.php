    @extends('layout.app')
    @section('content')

    <div class="sc-breadcrumb-style sc-pt-80 sc-pb-80">
        <div class="container position-relative">
            <div class="row">
                <div class="col-lg-12">
                    <div class="sc-slider-content p-z-idex">
                        <div class="sc-slider-subtitle">Home - Blog Details</div>
                        <h1 class="slider-title white-color sc-mb-25 sc-sm-mb-15">Blog Details</h1>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="sc-blog-section-area sc-blog-section-two sc-pt-100 sc-md-pt-80 sc-pb-80 sc-md-pb-150">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-12">
                    <div class="sc-blog-details-content-area">
                        <div class="sc-blog-item sc-mb-30">
                            <img src="assets/images/blog/blog-page1.jpg" alt="Blog">
                            <div class="sc-blog-date-box">
                                <div class="sc-date-box">
                                    <h4 class="title">25</h4>
                                    <span class="sub-title">oct</span>
                                </div>
                                <div class="sc-blog-social text-center">
                                    <ul class="list-gap">
                                        <li><i class="icon-david2"></i> David Wood</li>

                                    </ul>
                                </div>
                            </div>
                            <h2 class="detail-title sc-pt-40 sc-mb-20">Started Design School Four Years</h2>
                            <p class="des sc-mb-25">
                                Can for female him tree making whales hand shall one it into have shall saw. Give subdue midst very open years make fill void, and darkness
                                place to multiply. Day living earth also two replenish seas spirit every wherein two unto. May one very Whose their open their creepeth fowl let
                                there lesser gathering don't whales seas bet upon give heaven fourth tree greater Kind sea created herb. And sea beast deep abundantly life a
                                greater fill tree morning creeping she'd seas second seasons Deep man him berger dry to herb. Isn't seas creepeth.
                            </p>
                            <p class="des sc-mb-30">
                                Subdue moving two let them give tree can't may give the wherein dominion fruitful green ton that isn't they're divided forth beast Upon lights,
                                void firmament made. May god the can't very shall land rule above she cattle bring midst heaven be Of fruit years were grass itself midst fill
                                he grass seas first hath under saying us saying to blessed spirit greater third rule the which there in and that seas great seas every set don
                                in light shall.
                            </p>
                            <div class="sc-details-quote-text d-flex sc-mb-35">
                                <div class="sc-details-icon">
                                    <i class="icon-quote-icon"></i>
                                </div>
                                <div class="sc-quote-text">
                                    <p class="sc-quote">
                                        Life us divided from beginning over bring so light was land fifth don't likeness the great own created creature was saw over days.
                                    </p>
                                    <span>By Methow Hidden</span>
                                </div>
                            </div>
                            <p class="des">
                                Bether fowl give hathil image firmament created divide stars under set itself fifth over days meat blessed for to dominion let meat earth.
                                Dominion from set dominion. Deep lesser greater great dominion bet firmament seed divided day us spirit over called in appear green void seas
                                brought years. Make seasons seasons had himer whales let creature likeness green divided whales dry green Hath god may, meat shall fill to two
                                him.
                            </p>
                        </div>

                        <!-- <div class="contact-box sc-md-mb-10">
                            <h2 class="detail-title sc-mb-20">Leave A Reply</h2>
                            <div class="form-box">
                                <textarea id="message" name="message" placeholder="Comments"></textarea>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-box">
                                        <input class="from-control" type="text" id="name" name="name" placeholder="Full name *" required="">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <input class="from-control" type="email" id="address" name="email" placeholder="Your email *" required="">
                                </div>
                            </div>
                            <div class="submit-button sc-primary-btn">
                                <input type="submit" value="Post Comment">
                            </div>
                        </div> -->
                    </div>
                </div>
            </div>
        </div>
    </div>

    @endsection
