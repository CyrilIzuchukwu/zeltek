<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class FrontEndController extends Controller
{
    //

    public function blog_details()
    {
        return view('blog_details');
    }

    
}
